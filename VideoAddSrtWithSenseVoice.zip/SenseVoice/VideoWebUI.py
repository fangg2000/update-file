import gradio as gr
import os
import json
import time
import threading
import subprocess
import tempfile
import re

from pathlib import Path
from typing import Dict, List, Optional, Tuple

# 假设这些是已存在的模块
from video_util.AudioToSubtitleGenerator import AudioToSubtitleGenerator
from video_util.AudioUtil import AudioUtil
from video_util.SRTTranslator import SRTTranslator

from funasr import AutoModel
from funasr.utils.postprocess_utils import rich_transcription_postprocess

# 加载本地模型
model_dir = "./checkpoints/SenseVoiceSmall"
vad_model_dir = "./checkpoints/speech_fsmn_vad_zh-cn-16k-common-pytorch"

class VideoSubtitleGenerationGradio:
    def __init__(self):
        # 常量
        self.TRANSLATE_BAIDU = "百度翻译"
        self.TRANSLATE_GOOGLE = "谷歌翻译"
        self.A2TXT_API_URL = "http://127.0.0.1:8008/sense_voice/stt"

        # 模型
        self.model = None

        # 配置目录
        self.CONFIG_DIR = Path.home() / ".video_subtitle_tool"
        self.CONFIG_FILE = self.CONFIG_DIR / "baidu_keys.json"

        # 状态变量
        self.selected_file = None
        self.output_dir = None
        self.srt_file = None
        self.translate_srt_path = None
        self.video_file = None

        # 百度翻译配置
        self.baidu_app_id = ""
        self.baidu_secret_key = ""

        # 加载配置
        self.load_baidu_credentials()

        # 加载模型
        self.init_model()

    def load_baidu_credentials(self):
        """加载百度翻译凭据"""
        try:
            if self.CONFIG_FILE.exists():
                with open(self.CONFIG_FILE, 'r', encoding='utf-8') as f:
                    config = json.load(f)
                    self.baidu_app_id = config.get("app_id", "")
                    self.baidu_secret_key = config.get("secret_key", "")
                    return True
        except Exception as e:
            print(f"加载配置失败: {e}")
        return False

    def save_baidu_credentials(self, app_id: str, secret_key: str):
        """保存百度翻译凭据"""
        try:
            self.CONFIG_DIR.mkdir(parents=True, exist_ok=True)

            config = {
                "app_id": app_id,
                "secret_key": secret_key
            }

            with open(self.CONFIG_FILE, 'w', encoding='utf-8') as f:
                json.dump(config, f, ensure_ascii=False, indent=2)

            self.baidu_app_id = app_id
            self.baidu_secret_key = secret_key
            return True, "保存成功"
        except Exception as e:
            return False, f"保存失败: {e}"

    def get_current_time(self):
        """获取当前时间字符串"""
        return time.strftime("%H:%M:%S")

    def validate_segment_duration(self, duration_str: str):
        """验证分割时长"""
        try:
            duration = int(duration_str)
            if 5 <= duration <= 15:
                return True, duration
            else:
                return False, "分割时长必须在5-15秒之间"
        except ValueError:
            return False, "请输入有效的数字"

    def process_file(self,
                     file_path: str,
                     segment_duration: str,
                     enable_translation: bool,
                     translation_engine: str,
                     target_language: str,
                     app_id: str,
                     secret_key: str,
                     progress=gr.Progress()):
        """处理文件的主函数"""
        log_messages = []
        self.translate_srt_path = None

        def log(msg):
            timestamped_msg = f"[{self.get_current_time()}] {msg}"
            log_messages.append(timestamped_msg)
            print(timestamped_msg)

        try:
            # 验证输入
            if not file_path:
                return "", "错误：请先选择文件"

            valid, duration_or_error = self.validate_segment_duration(segment_duration)
            if not valid:
                return "", f"错误：{duration_or_error}"

            duration = duration_or_error

            if enable_translation:
                if translation_engine == self.TRANSLATE_BAIDU:
                    if not app_id or not secret_key:
                        return "", "错误：百度翻译需要API密钥"
                    # 保存凭据
                    self.save_baidu_credentials(app_id, secret_key)

            # 准备输出目录
            input_path = Path(file_path)
            self.selected_file = input_path
            self.output_dir = input_path.parent

            log(f"=== 开始处理流程 ===")
            log(f"文件: {input_path.name}")
            log(f"分割时长: {duration}秒")
            log(f"翻译: {'启用' if enable_translation else '禁用'}")
            if enable_translation:
                log(f"翻译引擎: {translation_engine}")
                log(f"目标语言: {target_language}")

            # 步骤1: 提取音频（如果是视频）
            file_name = input_path.name.lower()
            audio_path = None
            video_path = None
            video_flag = False

            if file_name.endswith(('.mp4', '.avi', '.mov', '.mkv')):
                log("检测到视频文件，正在提取音频...")
                audio_path = str(self.output_dir / f"a4v_{int(time.time())}.wav")

                if AudioUtil.audioFromVideo(str(input_path), audio_path, 22050):
                    log("✓ 音频提取完成")
                    video_path = str(input_path)
                    video_flag = True
                else:
                    log("✗ 音频提取失败")
                    return "\n".join(log_messages), "错误：音频提取失败"
            else:
                audio_path = str(input_path)
                log("✓ 已是音频文件，跳过提取步骤")

            # 步骤2: 平均切割大音频
            log("开始平均切割音频...")

            # 创建进度跟踪字典
            back_map = {"pro_over": 0, "progress": 0}

            # 启动进度监控线程
            def monitor_avg_cut_progress():
                while back_map.get("pro_over", 0) != 1:
                    progress_value = back_map.get("progress", 0)
                    progress((progress_value / 100) * 0.3, desc="平均切割进度")
                    time.sleep(0.5)

            progress_thread = threading.Thread(target=monitor_avg_cut_progress)
            progress_thread.start()

            cut_avg_dir = AudioUtil.cutAudio4MroeByAvg(audio_path, str(self.output_dir), back_map)
            back_map["pro_over"] = 1

            if not cut_avg_dir:
                log("✗ 音频切割失败")
                return "\n".join(log_messages), "错误：音频切割失败"

            progress(0.3, desc="平均切割完成")
            log("✓ 平均切割完成")

            # 步骤3: 精细切割（基于静默检测）
            log("开始精细切割（静默检测）...")

            back_map = {"pro_over": 0, "progress": 0}

            def monitor_small_cut_progress():
                while back_map.get("pro_over", 0) != 1:
                    progress_value = back_map.get("progress", 0)
                    progress(0.3 + (progress_value / 100) * 0.3, desc="精细切割进度")
                    time.sleep(0.5)

            progress_thread = threading.Thread(target=monitor_small_cut_progress)
            progress_thread.start()

            time_info_path = AudioUtil.checkFinalSilence4Audio(audio_path, cut_avg_dir, duration, back_map)
            back_map["pro_over"] = 1

            if not time_info_path:
                log("✗ 精细切割失败")
                return "\n".join(log_messages), "错误：精细切割失败"

            progress(0.6, desc="精细切割完成")
            log("✓ 精细切割完成")

            # 步骤4: 调用Python接口推理文本
            log("开始调用Python接口生成文本...")

            time.sleep(1)

            back_map = {"pro_over": 0, "progress": 0}

            def monitor_inference_progress():
                while back_map.get("pro_over", 0) != 1:
                    progress_value = back_map.get("progress", 0)
                    progress(0.6 + (progress_value / 100) * 0.3, desc="文本推理进度")
                    time.sleep(0.5)

            progress_thread = threading.Thread(target=monitor_inference_progress)
            progress_thread.start()

            # 解析时间信息路径
            file_arr = time_info_path.split("#")
            if len(file_arr) < 2:
                log("✗ 时间信息文件格式错误")
                return "\n".join(log_messages), "错误：时间信息文件格式错误"

            result_srt_path = AudioToSubtitleGenerator.generate_subtitle_from_audio(
                file_arr[0],
                file_arr[1],
                back_map,
                1,
                self.model
            )
            back_map["pro_over"] = 1

            if not result_srt_path:
                log("✗ 字幕生成失败")
                return "\n".join(log_messages), "错误：字幕生成失败"

            progress(0.9, desc="字幕生成完成")
            log("✓ SRT文件已生成")

            # 步骤5: 翻译（如果启用）
            translate_path = None
            if enable_translation:
                if translation_engine == self.TRANSLATE_BAIDU:
                    log("开始使用百度翻译字幕文本...")

                    # 解析源语言和目标语言
                    langs = target_language.split(">")
                    if len(langs) != 2:
                        source_lang = "zh"
                        target_lang_code = "en"
                    else:
                        source_lang = langs[0]
                        target_lang_code = langs[1]

                    translate_path = str(self.output_dir / f"translate_{int(time.time())}.srt")

                    try:
                        srt_translator = SRTTranslator(app_id, secret_key)
                        srt_translator.translate_srt_file(
                            srt_translator,
                            in_srt_path = result_srt_path,
                            out_srt_path = translate_path,
                            from_lang = source_lang,
                            to_lang = target_lang_code,
                            bilingual = False,# true双语字幕，false翻译字幕
                            delay_ms = 1000# 延迟
                        )

                        # if success:
                        #     log("✓ 翻译完成")
                        # else:
                        #     log("✗ 翻译失败")
                        #     translate_path = None
                    except Exception as e:
                        log(f"✗ 翻译出错: {e}")
                        translate_path = None
                elif translation_engine == self.TRANSLATE_GOOGLE:
                    log("注意：谷歌翻译功能暂未实现")

            # 使用翻译后的字幕文件（如果存在），否则使用原始字幕文件
            # subtitle_path = translate_path if translate_path else result_srt_path
            self.srt_file = Path(result_srt_path)

            # 步骤6: 视频合并字幕处理（如果原始是视频文件）
            if video_flag:
                result_video_path = str(self.output_dir / f"video_result_{int(time.time())}.mp4")
                print(f"视频路径--{video_path}");
                print(f"翻译字幕--{translate_path}");

                if translate_path is not None:
                    self.translate_srt_path = translate_path

                    # 分两个字幕文件合并，可分别指定字体大小
                    if AudioUtil.srt2VideoByDouble(result_srt_path, translate_path, video_path, result_video_path):
                        log("✓ 视频字幕合并完成")
                        log(f"输出文件: {result_video_path}")
                        return "\n".join(log_messages), "合并完成！"
                    else:
                        log("✗ 视频合并双字幕失败")
                else:
                    if AudioUtil.srt2Video(result_srt_path, video_path, result_video_path, None):
                        log("✓ 视频字幕合并完成")
                        log(f"输出文件: {result_video_path}")
                        return "\n".join(log_messages), "合并完成！"
                    else:
                        log("✗ 视频合并单字幕失败")

            else:
                if translate_path:
                    self.translate_srt_path = translate_path
                log("不是视频文件，跳过合并字幕步骤")

            progress(1.0, desc="处理完成")
            log("=== 处理流程完成 ===")
            log(f"输出目录: {self.output_dir}")

            # 生成结果文件列表
            result_files = []
            if self.srt_file.exists():
                result_files.append(str(self.srt_file))
            if video_flag and Path(result_video_path).exists():
                result_files.append(result_video_path)

            return "\n".join(log_messages), "处理完成！"

        except Exception as e:
            log(f"✗ 处理过程中出错: {e}")
            return "\n".join(log_messages), f"错误：{str(e)}"

    def merge_subtitle_to_video(self, video_file: str, srt_file: str):
        """合并字幕到视频"""
        log_messages = []

        def log(msg):
            timestamped_msg = f"[{self.get_current_time()}] {msg}"
            log_messages.append(timestamped_msg)
            print(timestamped_msg)

        try:
            if not video_file or not srt_file:
                return "", "错误：请选择视频文件和原字幕文件（如果刚刚执行「字幕生成」操作，并且翻译成功，则会一起合并处理成双字幕）"

            video_path = Path(video_file)
            srt_path = Path(srt_file)

            if not srt_path.exists():
                return "", "错误：字幕文件不存在"

            output_dir = video_path.parent
            result_video_path = str(output_dir / f"vccs_{int(time.time())}.mp4")

            log("开始合并字幕到视频...")

            if self.translate_srt_path is not None:
                log("使用双字幕合成到视频")

                # 分两个字幕文件合并，可分别指定字体大小
                if AudioUtil.srt2VideoByDouble(str(srt_path), self.translate_srt_path, str(video_path), result_video_path):
                    log("✓ 视频字幕合并完成")
                    log(f"输出文件: {result_video_path}")
                    return "\n".join(log_messages), "合并完成！"
                else:
                    log("✗ 视频字幕合并失败")
                    return "\n".join(log_messages), "错误：合并失败"
            else:
                log("使用单字幕合成到视频")

                # 单个字幕文件合并
                if AudioUtil.srt2Video(str(srt_path), str(video_path), result_video_path, None):
                    log("✓ 视频字幕合并完成")
                    log(f"输出文件: {result_video_path}")
                    return "\n".join(log_messages), "合并完成！"
                else:
                    log("✗ 视频字幕合并失败")
                    return "\n".join(log_messages), "错误：合并失败"
        except Exception as e:
            log(f"✗ 合并过程中出错: {e}")
            return "\n".join(log_messages), f"错误：{str(e)}"

    def create_ui(self):
        """创建Gradio界面"""
        with gr.Blocks(title="视频字幕生成工具 v1.0", theme=gr.themes.Soft()) as demo:
            gr.Markdown("# 🎬 视频字幕生成工具")

            with gr.Tabs():
                with gr.TabItem("字幕生成"):
                    # 文件选择区域
                    with gr.Row():
                        with gr.Column(scale=3):
                            file_input = gr.File(
                                label="选择视频/音频文件",
                                file_types=["video", "audio"],
                                type="filepath"
                            )
                        with gr.Column(scale=2):
                            segment_duration = gr.Number(
                                label="显示字幕时长(秒)",
                                value=10,
                                minimum=5,
                                maximum=15,
                                step=1
                            )

                    # 翻译选项
                    with gr.Row():
                        enable_translation = gr.Checkbox(
                            label="翻译字幕 (生成双语SRT)",
                            value=False
                        )

                        translation_engine = gr.Dropdown(
                            label="翻译引擎",
                            choices=[self.TRANSLATE_BAIDU, self.TRANSLATE_GOOGLE],
                            value=self.TRANSLATE_BAIDU,
                            interactive=False
                        )

                        target_language = gr.Dropdown(
                            label="目标语言",
                            choices=["zh>en", "en>zh"],
                            value="zh>en",
                            interactive=False
                        )

                    # 百度翻译配置
                    with gr.Group(visible=False) as baidu_config_group:
                        with gr.Row():
                            app_id_input = gr.Textbox(
                                label="Api Key",
                                value=self.baidu_app_id,
                                placeholder="请输入百度翻译API的Api Key"
                            )

                            secret_key_input = gr.Textbox(
                                label="Secret Key",
                                value=self.baidu_secret_key,
                                placeholder="请输入百度翻译API的Secret Key",
                                type="password"
                            )

                        with gr.Row():
                            save_key_btn = gr.Button("保存密钥", variant="secondary")

                    # 处理按钮
                    process_btn = gr.Button("一键开始", variant="primary", size="lg")

                    # 日志区域
                    log_output = gr.Textbox(
                        label="处理日志",
                        lines=15,
                        max_lines=20,
                        interactive=False
                    )

                    # 状态标签
                    status_label = gr.Label("就绪", label="状态")

                with gr.TabItem("合并字幕"):
                    with gr.Row():
                        video_file_input = gr.File(
                            label="选择视频文件",
                            file_types=["video"],
                            type="filepath"
                        )

                        srt_file_input = gr.File(
                            label="选择字幕文件 (.srt)",
                            file_types=[".srt"],
                            type="filepath"
                        )

                    merge_btn = gr.Button("合并字幕到视频", variant="primary")

                    merge_log_output = gr.Textbox(
                        label="合并日志",
                        lines=10,
                        max_lines=15,
                        interactive=False
                    )

                    merge_status_label = gr.Label("就绪", label="状态")

            # 交互逻辑
            # 翻译复选框状态变化
            def on_translation_checkbox_change(checked):
                engine_interactive = checked
                lang_interactive = checked
                baidu_config_visible = checked
                return [
                    gr.update(interactive=engine_interactive),
                    gr.update(interactive=lang_interactive),
                    gr.update(visible=baidu_config_visible)
                ]

            enable_translation.change(
                on_translation_checkbox_change,
                inputs=[enable_translation],
                outputs=[translation_engine, target_language, baidu_config_group]
            )

            # 保存密钥按钮
            def on_save_key(app_id, secret_key):
                success, message = self.save_baidu_credentials(app_id, secret_key)
                return gr.update(value=message), "密钥已保存" if success else "保存失败"

            save_key_btn.click(
                on_save_key,
                inputs=[app_id_input, secret_key_input],
                outputs=[log_output, status_label]
            )

            # 处理按钮
            process_btn.click(
                self.process_file,
                inputs=[
                    file_input,
                    segment_duration,
                    enable_translation,
                    translation_engine,
                    target_language,
                    app_id_input,
                    secret_key_input
                ],
                outputs=[log_output, status_label],
                show_progress="full"
            )

            # 合并按钮
            merge_btn.click(
                self.merge_subtitle_to_video,
                inputs=[video_file_input, srt_file_input],
                outputs=[merge_log_output, merge_status_label],
                show_progress="full"
            )

            # 加载时显示欢迎信息
            demo.load(
                fn=lambda: (f"[{self.get_current_time()}] 应用程序启动\n", "就绪"),
                outputs=[log_output, status_label]
            )

        return demo

    def init_model(self):
        self.model = AutoModel(
            model=model_dir,
            trust_remote_code=True,
            remote_code="./model.py",
            # vad_model="fsmn-vad",
            vad_model=vad_model_dir,
            vad_kwargs={"max_single_segment_time": 30000},
            device="cuda:0",
        )

        print("音频转文本模型加载成功")


def main():
    """主函数"""
    app = VideoSubtitleGenerationGradio()
    demo = app.create_ui()
    demo.launch(
        server_name="127.0.0.1",
        server_port=7860,
        share=False,
        show_error=True
    )


if __name__ == "__main__":
    main()