import os
import sys
import re
import subprocess
import threading
import time
import math
import decimal
import shutil
import tempfile
import logging
from pathlib import Path
from typing import List, Dict, Tuple, Optional, Any, Union
from dataclasses import dataclass
from enum import Enum
from concurrent.futures import ThreadPoolExecutor, Future
import wave
import numpy as np
from pydub import AudioSegment
from pydub.utils import mediainfo

# 设置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class AudioUtil:
    """音频处理工具类"""

    class LogType(Enum):
        """日志类型枚举"""
        DEFAULT = 0  # 基础日志
        UN_CONSOLE = -1  # 不输出日志
        STARTUP_SIGNAL = -2  # 启动信号监控
        VERBOSE_LOG = 1  # 详细日志

    # 系统类型
    SYS_TYPE_WINDOWS = "Windows"
    SYS_TYPE_LINUX = "Linux"

    # 全局变量
    _executor = ThreadPoolExecutor(max_workers=4)
    _sys_type = sys.platform
    _ffmpeg_exe = None
    _sox_exe = None

    @classmethod
    def _get_ffmpeg_path(cls) -> str:
        """获取FFmpeg路径"""
        if cls._ffmpeg_exe:
            return cls._ffmpeg_exe

        if cls._sys_type.startswith("linux") or cls._sys_type == "darwin":
            # Linux/Mac
            cls._ffmpeg_exe = "ffmpeg"
        else:
            # Windows
            try:
                # 方法1: 使用where命令
                result = subprocess.run(["where", "ffmpeg.exe"],
                                        capture_output=True,
                                        text=True,
                                        check=False)
                if result.returncode == 0 and result.stdout.strip():
                    cls._ffmpeg_exe = result.stdout.strip().split('\n')[0]
                    return "ffmpeg.exe"

                # 方法2: 检查常见安装路径
                common_paths = [
                    r"C:\ffmpeg\bin\ffmpeg.exe",
                    r"C:\Program Files\ffmpeg\bin\ffmpeg.exe",
                    r"C:\Program Files (x86)\ffmpeg\bin\ffmpeg.exe",
                ]

                for path in common_paths:
                    if os.path.exists(path):
                        cls._ffmpeg_exe = path
                        return "ffmpeg.exe"

                # 方法3: 尝试从PATH环境变量中查找
                cls._ffmpeg_exe = "ffmpeg.exe"
            except Exception as e:
                logger.warning(f"查找FFmpeg路径失败: {e}")
                cls._ffmpeg_exe = "ffmpeg.exe"

        return cls._ffmpeg_exe

    @classmethod
    def _get_sox_path(cls) -> str:
        """获取SoX路径"""
        if cls._sox_exe:
            return cls._sox_exe

        if cls._sys_type.startswith("linux") or cls._sys_type == "darwin":
            cls._sox_exe = "sox"
        else:
            # Windows默认路径
            default_path = r"C:\Program Files (x86)\sox-14-4-2\sox.exe"
            if os.path.exists(default_path):
                cls._sox_exe = default_path
            else:
                # 尝试查找其他路径
                cls._sox_exe = "sox"

        return cls._sox_exe

    @staticmethod
    def cutAudio4MroeByAvg(audioPath: str, savePath: str, backMap: Dict[str, int]) -> Optional[str]:
        """大音频切割为多个音频(平均切割)"""
        logger.info("大音频切割为多个音频")

        file_num = 10001
        audio_file = Path(audioPath)
        new_path = Path(savePath) / f"avgcut_{int(time.time() * 1000)}"
        AudioUtil.newDirFile(new_path)

        start_time = None
        end_time = None
        total_count = 0
        count = 0
        sum_duration = 0
        cut_duration = 30000  # 每个音频30秒

        try:
            if audio_file.suffix.lower() in ['.wav', '.mp3']:
                sum_duration = AudioUtil.audioDuration(str(audio_file))

                last_cut_time = 0
                while last_cut_time < sum_duration:
                    # 处理进度
                    progress = min(100.0, (count * cut_duration / sum_duration * 100) if sum_duration > 0 else 0)
                    progress = round(progress * 100.0) / 100.0
                    backMap["progress"] = int(progress)

                    if (last_cut_time + cut_duration) < sum_duration:
                        start_time = AudioUtil.second2VoiceTime(last_cut_time / 1000.0)
                        end_time = AudioUtil.second2VoiceTime((last_cut_time + cut_duration) / 1000.0)

                        output_file = new_path / f"cut_{file_num}.wav"
                        if AudioUtil.cut_audio(str(audio_file), start_time, end_time, str(output_file)):
                            count += 1
                        else:
                            logger.warning(f"切割失败--{file_num}")

                        file_num += 1
                        total_count += 1
                        last_cut_time += cut_duration
                    else:
                        start_time = AudioUtil.second2VoiceTime(last_cut_time / 1000.0)
                        output_file = new_path / f"cut_{file_num}.wav"
                        if AudioUtil.cutAudioStartAndWithoutEnd(str(audio_file), start_time, None, str(output_file)):
                            count += 1

                        file_num += 1
                        total_count += 1
                        break

                logger.info(f"{audio_file.name}切割音频总数量: {total_count}")

        except Exception as e:
            logger.error(f"音频切割为多个音频异常: {e}", exc_info=True)
            return None
        finally:
            backMap["pro_over"] = 1

        logger.info(f"生成音频数量: {count}")
        return str(new_path)

    @staticmethod
    def checkFinalSilence4Audio(audioPath: str, audioDirPath: str, aDuration: int,
                                backMap: Dict[str, int]) -> Optional[str]:
        """判断切割的音频最后一段静默时间"""
        audio_dir = Path(audioDirPath)
        time_arr = None
        first_time = 0
        last_time = 0
        cache_time = 0
        file_num = 10001
        count = 0
        duration = 30000
        max_duration = aDuration * 1000

        save_path = audio_dir.parent / f"cut_{int(time.time() * 1000)}"
        AudioUtil.newDirFile(save_path)
        srt_path = save_path / "time.srt"

        try:
            path_map = {}

            # 记录字幕对应时间点
            srt_content = []

            # 收集音频文件
            for audio_file in audio_dir.iterdir():
                if audio_file.suffix.lower() in ['.wav', '.mp3']:
                    path_map[audio_file.name] = str(audio_file)

            # 按文件名排序
            sorted_files = sorted(path_map.items())
            total_files = len(sorted_files)

            for file_name, file_path in sorted_files:
                logger.info(f"切割音频--{file_name}")
                time_arr = AudioUtil.cutAudio(file_path, 300, -12, 0, None)

                for time_map in time_arr:
                    current_start = time_map.get("start_time", 0) + (duration * count)
                    current_end = time_map.get("end_time", 0) + (duration * count)

                    # 大于指定时长
                    if last_time > 0 and (current_start - first_time) > max_duration:
                        start_time_str = AudioUtil.second2VoiceTime(first_time / 1000.0)

                        cache_time = last_time + (duration * count) + (
                                    (current_start - (last_time + (duration * count))) // 2)
                        end_time_str = AudioUtil.second2VoiceTime(cache_time / 1000.0)

                        first_time = cache_time

                        try:
                            output_file = save_path / f"{file_num}.wav"
                            if AudioUtil.cut_audio(audioPath, start_time_str, end_time_str, str(output_file)):
                                srt_content.append(f"{file_num}#{start_time_str}#{end_time_str}")
                                file_num += 1
                        except Exception as e:
                            logger.warning(f"切割失败时间点--{cache_time}: {e}")

                    last_time = time_map.get("end_time", 0)

                # 处理进度
                progress = min(100.0, (count / total_files * 100) if total_files > 0 else 0)
                progress = round(progress * 100.0) / 100.0
                backMap["progress"] = int(progress)

                count += 1

            # 生成.srt字幕文件
            if srt_content:
                with open(srt_path, 'w', encoding='utf-8') as f:
                    f.write('\n'.join(srt_content))

        except Exception as e:
            logger.error(f"检查静默时间异常: {e}", exc_info=True)
            return None
        finally:
            backMap["pro_over"] = 1

        return f"{save_path}#{srt_path}"

    @staticmethod
    def newDirFile(path: Union[str, Path]) -> Path:
        """创建新目录"""
        path_obj = Path(path)
        if not path_obj.exists():
            path_obj.mkdir(parents=True, exist_ok=True)
        return path_obj

    @staticmethod
    def audioDuration(filePath: str) -> int:
        """音频时长(毫秒)"""
        try:
            audio_info = mediainfo(filePath)
            duration_ms = float(audio_info.get('duration', 0)) * 1000
            return int(duration_ms)
        except Exception as e:
            logger.error(f"获取音频时长失败: {e}")
            return 0

    @staticmethod
    def second2VoiceTime(secondTime: float) -> str:
        """秒转换音频时间格式"""
        second_d = round(secondTime, 3)

        if second_d >= 3600:
            hours = int(second_d) // 3600
            minutes = (int(second_d) % 3600) // 60
            seconds = second_d % 60

            return f"{hours:02d}:{minutes:02d}:{seconds:06.3f}"
        elif second_d >= 60:
            minutes = int(second_d) // 60
            seconds = second_d % 60

            return f"00:{minutes:02d}:{seconds:06.3f}"
        else:
            return f"00:00:{second_d:06.3f}"

    @staticmethod
    def cutAudio(filePath: str, min_silence_len: Optional[int] = None,
                 silence_thresh: Optional[int] = None, keep_silence: Optional[int] = None,
                 backMap: Optional[Dict[str, int]] = None) -> List[Dict[str, int]]:
        """切割音频"""
        return AudioUtil._cutAudioImpl(filePath, min_silence_len, silence_thresh,
                                       keep_silence, backMap, {})

    @staticmethod
    def _cutAudioImpl(filePath: str, min_silence_len: Optional[int],
                      silence_thresh: Optional[int], keep_silence: Optional[int],
                      backMap: Optional[Dict[str, int]], backTimeMap: Dict[int, int]) -> List[Dict[str, int]]:
        """切割音频实现"""
        try:
            # 读取音频数据
            audio = AudioSegment.from_file(filePath)
            sample_rate = audio.frame_rate
            channels = audio.channels

            # 转换为单声道并获取样本数据
            if channels > 1:
                audio = audio.set_channels(1)

            # 获取原始数据
            samples = np.array(audio.get_array_of_samples())

            # 设置参数
            msl = min_silence_len if min_silence_len is not None else 1000
            st = silence_thresh if silence_thresh is not None else -10
            ks = keep_silence if keep_silence is not None else 30

            # 解释波形数据
            time_map = AudioUtil.explainFFT(samples, sample_rate, 1500, 500, st)

            if backTimeMap is not None:
                backTimeMap.update(time_map)

            cache_list = []
            result_list = []
            cut_time_list = []

            start_time = 0
            end_time = 0
            min_time = 0
            max_time = 0
            silence_num = 0
            voice_num = 0
            cut_num = 0
            hide_flag = False
            start_flag = False

            for timestamp, value in sorted(time_map.items()):
                if not start_flag:
                    min_time = timestamp
                    start_flag = True

                if timestamp > max_time:
                    max_time = timestamp

                if value == 0:
                    silence_num += 1
                    cut_num += 1

                    if silence_num > 3:
                        if hide_flag and voice_num > 10:
                            cache_list.append({
                                "start_time": start_time,
                                "end_time": end_time
                            })

                        hide_flag = False
                        voice_num = 0
                else:
                    if not hide_flag:
                        start_time = timestamp
                        hide_flag = True
                    else:
                        end_time = timestamp

                    voice_num += 1
                    silence_num = 0

                    if voice_num > 10:
                        if (cut_num * 5) >= msl:
                            cut_time_list.append(start_time)
                        cut_num = 0

            # 添加最后一段
            if voice_num > 10 and hide_flag:
                cache_list.append({
                    "start_time": start_time,
                    "end_time": end_time
                })

            # 处理切割时间点
            cut_start_time = 0
            last_end_time = 0
            cut_flag = False

            for segment in cache_list:
                if not cut_flag:
                    cut_start_time = segment["start_time"]
                    cut_flag = True

                for cut_time in cut_time_list:
                    if last_end_time > 0 and cut_time == segment["start_time"]:
                        result_list.append({
                            "start_time": max(cut_start_time - ks, 0),
                            "end_time": min(last_end_time + ks, max_time)
                        })

                        cut_start_time = segment["start_time"]
                        last_end_time = 0
                        break

                last_end_time = segment["end_time"]

            if last_end_time > 0:
                result_list.append({
                    "start_time": max(cut_start_time - ks, min_time),
                    "end_time": min(last_end_time + ks, max_time)
                })

            # 更新返回映射
            if backMap is not None:
                backMap["minTime"] = min_time
                backMap["maxTime"] = max_time
                backMap["sampleRate"] = sample_rate
                backMap["duration"] = len(audio)

            return result_list

        except Exception as e:
            logger.error(f"音频切割失败: {e}", exc_info=True)
            return []

    @staticmethod
    def explainFFT(data: np.ndarray, sample_rate: int, ww: int, hh: int,
                   silence_thresh: int) -> Dict[int, int]:
        """解释波形数据(取水平轴下面的数据)"""
        result_map = {}

        # 每1ms的采样数
        per_ms_sr = sample_rate // 1000
        per = 5
        per_ms = per_ms_sr * per

        k = hh / 2.0 / 32768.0
        avg = 233  # 水平轴线值
        deviate_min = silence_thresh

        num = per
        sum_val = 0
        sum_count = 0

        for j in range(len(data)):
            y = hh - int(data[j] * k + hh / 2)

            # 水平轴下面的数据
            if y < (avg - deviate_min):
                sum_val += y
                sum_count += 1

            if j % per_ms == 0:
                result_map[num - per] = sum_val // sum_count if sum_count > 0 else 0
                num += per
                sum_val = 0
                sum_count = 0

        return result_map

    @staticmethod
    def audioDataReader(filePath: str, sample_rate: int, *cutFlag) -> np.ndarray:
        """短音频数据处理（30秒内）"""
        try:
            if cutFlag and len(cutFlag) > 0 and cutFlag[0]:
                if sample_rate not in [22050, 44100]:
                    logger.warning(f"短音频处理不支持【{sample_rate}】音频采样率，仅支持22050和44100采样率")
                    raise ValueError(f"不支持的采样率: {sample_rate}")

            audio = AudioSegment.from_file(filePath)

            # 转换为指定采样率
            if audio.frame_rate != sample_rate:
                audio = audio.set_frame_rate(sample_rate)

            # 转换为单声道
            if audio.channels > 1:
                audio = audio.set_channels(1)

            # 获取样本数据
            samples = np.array(audio.get_array_of_samples())

            return samples

        except Exception as e:
            logger.error(f"音频数据读取失败: {e}")
            return AudioUtil.audioLongDataReader(filePath, sample_rate, *cutFlag)

    @staticmethod
    def audioLongDataReader(filePath: str, sample_rate: int, *cutFlag) -> np.ndarray:
        """长音频数据处理（30秒以上）"""
        try:
            audio = AudioSegment.from_file(filePath)

            # 转换为单声道
            if audio.channels > 1:
                audio = audio.set_channels(1)

            # 获取样本数据
            samples = np.array(audio.get_array_of_samples())

            return samples

        except Exception as e:
            logger.error(f"长音频数据读取失败: {e}", exc_info=True)
            return np.array([])

    @staticmethod
    def fileWrite(path: str, content: str) -> None:
        """写入文件"""
        try:
            file_path = Path(path)
            file_path.parent.mkdir(parents=True, exist_ok=True)

            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)
        except Exception as e:
            logger.error(f"文件写入失败: {e}")

    @staticmethod
    def unicodeToCN(text: str) -> str:
        """Unicode转换中文"""
        pattern = re.compile(r'\\u([0-9a-fA-F]{4})')

        def replace_unicode(match):
            hex_str = match.group(1)
            try:
                return chr(int(hex_str, 16))
            except:
                return match.group(0)

        return pattern.sub(replace_unicode, text)

    @staticmethod
    def cut_audio(inputPath: str, startTime: Optional[str], endTime: Optional[str], outputPath: str) -> bool:
        """切割音频(取时间点的最近帧切割)"""
        try:
            ffmpeg_path = AudioUtil._get_ffmpeg_path()
            command = [ffmpeg_path, '-i', inputPath]

            if startTime or endTime:
                if startTime:
                    command.extend(['-ss', startTime])
                if endTime:
                    command.extend(['-to', endTime])
            else:
                return False

            command.extend(['-c', 'copy', outputPath])

            return AudioUtil.ffCommandRun(command, -1)
        except Exception as e:
            logger.error(f"音频切割失败: {e}")
            return False

    @staticmethod
    def cutAudioStartAndWithoutEnd(inputPath: str, startTime: str,
                                   endTime: Optional[str], outputPath: str) -> bool:
        """只根据开始时间切割音频(精准)"""
        try:
            ffmpeg_path = AudioUtil._get_ffmpeg_path()
            command = [ffmpeg_path, '-ss', startTime, '-i', inputPath, '-c', 'copy', outputPath]

            return AudioUtil.ffCommandRun(command, -1)
        except Exception as e:
            logger.error(f"音频切割失败: {e}")
            return False
    
    @staticmethod
    def audioFromVideo(videoPath: str, outAudioPath: str, sampleRate: Optional[int] = None) -> bool:
        """从视频中提取音频"""
        try:
            ffmpeg_path = AudioUtil._get_ffmpeg_path()
            sr = sampleRate if sampleRate is not None else 22050

            command = [
                ffmpeg_path, '-i', videoPath,
                '-vn', '-acodec', 'pcm_s16le',
                '-ar', str(sr),
                '-ac', '1',
                outAudioPath
            ]

            return AudioUtil.ffCommandRun(command, -1)
        except Exception as e:
            logger.error(f"视频提取音频失败: {e}")
            return False

    @staticmethod
    def srt2Video(srtPath: str, videoPath: str, outPath: str, fontName: Optional[str] = None) -> bool:
        """给视频加上字幕（兼容.ass）"""
        
        video = Path(f"{videoPath}")
        srt   = Path(f"{srtPath}")
        out   = Path(f"{outPath}")
        # 关键：把反斜杠换成「/」或「\\」
        video_file = video.as_posix()
        # 针对盘符特别处理
        srt_file = srt.as_posix().replace(":", "\\\\:")
        out_file = out.as_posix()
        
        try:
            ffmpeg_path = AudioUtil._get_ffmpeg_path()
            #ffmpeg_path = "ffmpeg.exe"
            ffmpeg_path = str(ffmpeg_path).replace("\\", "\\\\")
            force_style = f":force_style='FontName={fontName}'" if fontName else ""
            command = [
                ffmpeg_path, '-threads', '2',
                '-i', video_file,
                '-vf', f"subtitles={srt_file}{force_style}",
                '-c:a', 'copy',
                '-max_muxing_queue_size', '1024',
                out_file
            ]
            
            print(f"视频路径--{str(command)}");
            return AudioUtil.ffCommandRun(command, 1)
        except Exception as e:
            logger.error(f"字幕添加失败: {e}")
            return False

    # 双层字幕
    @staticmethod
    def srt2VideoByDouble(
            originalSubPath: str,  # 原始字幕文件路径
            translatedSubPath: str,  # 翻译字幕文件路径
            videoPath: str,  # 输入视频路径
            outPath: str,  # 输出视频路径
            originalFontName: str = "Arial",  # 原始字幕字体
            translatedFontName: str = "Arial",  # 翻译字幕字体
            originalFontSize: int = 14,  # 原始字幕大小
            translatedFontSize: int = 10,  # 翻译字幕大小
            originalColor: str = "&HFFFFFF",  # 原始字幕颜色（白色）
            translatedColor: str = "&H00FFFF",  # 翻译字幕颜色（青色）
            originalAlignment: int = 2,  # 原始字幕对齐（2=底部居中）
            translatedAlignment: int = 2,  # 翻译字幕对齐
            marginV: int = 30,  # 翻译字幕垂直边距
            outline: int = 1,  # 描边大小
            outlineColor: str = "&H000000",  # 描边颜色（黑色）
            originalMarginV: int = 25,     # 原始字幕垂直边距
            translatedMarginV: int = 5,   # 翻译字幕垂直边距
            lineSpacing: int = 15          # 两行字幕之间的间距
    ) -> bool:
        """给视频添加双层字幕（原始+翻译）"""
        try:
            original_path = Path(f"{originalSubPath}").as_posix().replace(":", "\\\\:")
            translate_path = Path(f"{translatedSubPath}").as_posix().replace(":", "\\\\:")
            video_path = Path(f"{videoPath}").as_posix()
            out_path = Path(f"{outPath}").as_posix()
			
            ffmpeg_path = AudioUtil._get_ffmpeg_path()
            ffmpeg_path = str(ffmpeg_path).replace("\\", "\\\\")
            # 在构建filter_complex时计算位置
            translated_margin = translatedMarginV
            original_margin = translated_margin + translatedFontSize + lineSpacing

            # 构建filter_complex参数
            filter_complex = (
                f"[0:v]subtitles={original_path}:"
                f"force_style='FontName={originalFontName},"
                f"FontSize={originalFontSize},"
                f"PrimaryColour={originalColor},"
                f"OutlineColour={outlineColor},"
                f"Outline={outline},"
                f"Alignment={originalAlignment},MarginV={original_margin}'[base];"

                f"[base]subtitles={translate_path}:"
                f"force_style='FontName={translatedFontName},"
                f"FontSize={translatedFontSize},"
                f"PrimaryColour={translatedColor},"
                f"OutlineColour={outlineColor},"
                f"Outline={outline},"
                f"Alignment={translatedAlignment},"
                f"MarginV={translated_margin}'"
            )

            command = [
                ffmpeg_path, '-threads', '2',
                '-i', video_path,
                '-filter_complex', filter_complex,
                '-c:a', 'copy',
                '-max_muxing_queue_size', '1024',
                out_path
            ]

            print(f"视频路径--{str(command)}");
            return AudioUtil.ffCommandRun(command, 1)
        except Exception as e:
            logger.error(f"双层字幕添加失败: {e}")
            return False

    @staticmethod
    def ffCommandRun(command: List[str], logType: int) -> bool:
        """命令行执行入口"""
        log_type = AudioUtil.LogType.DEFAULT
        timeout = None

        if logType == -2:
            log_type = AudioUtil.LogType.STARTUP_SIGNAL
            timeout = 15
        elif logType == -1:
            log_type = AudioUtil.LogType.UN_CONSOLE
        elif logType == 1:
            log_type = AudioUtil.LogType.VERBOSE_LOG

        return AudioUtil.executeCommand(command, log_type, None, timeout)

    @staticmethod
    def executeCommand(command: List[str], logType: 'AudioUtil.LogType',
                       resultMap: Optional[Dict[str, Any]] = None,
                       timeoutSeconds: Optional[float] = None) -> bool:
        """执行命令"""
        try:
            logger.info(f"执行命令: {' '.join(command)}")

            # 设置超时
            timeout = timeoutSeconds if timeoutSeconds else None

            # 执行命令
            process = subprocess.Popen(
                command,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                universal_newlines=True,
                encoding='utf-8'
            )

            # 处理输出流
            def process_stream():
                line_count = 0
                max_lines = 100

                for line in process.stdout:
                    if logType == AudioUtil.LogType.STARTUP_SIGNAL:
                        if "APPLICATION STARTUP COMPLETE" in line.upper():
                            return
                        if resultMap is not None and line_count < max_lines:
                            resultMap[str(line_count)] = line.strip()
                            line_count += 1
                        continue

                    if logType == AudioUtil.LogType.UN_CONSOLE and resultMap is not None:
                        if "mean_volume" in line:
                            match = re.search(r"mean_volume: ([-+]?\d*\.?\d+) dB", line)
                            if match:
                                resultMap["volume"] = float(match.group(1))
                        continue

                    if logType == AudioUtil.LogType.DEFAULT:
                        if line.startswith("Output"):
                            logger.info(f"[INFO] {line.strip()}")
                    elif logType == AudioUtil.LogType.VERBOSE_LOG:
                        print(f"[INFO] {line.strip()}")
                        logger.info(f"[INFO] {line.strip()}")

            # 在单独的线程中处理输出
            stream_thread = threading.Thread(target=process_stream)
            stream_thread.daemon = True
            stream_thread.start()

            # 等待进程完成
            try:
                process.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
                return False

            return process.returncode == 0

        except Exception as e:
            logger.error(f"命令执行失败: {e}", exc_info=True)
            print(f"命令执行失败: {e}")
            return False

    @staticmethod
    def getAudioInfo(audioFile: Union[str, Path]) -> Optional[Dict[str, Any]]:
        """获取音频信息"""
        try:
            audio_file = Path(audioFile) if isinstance(audioFile, str) else audioFile
            if not audio_file.exists():
                logger.error(f"音频文件不存在: {audio_file}")
                return None

            info = mediainfo(str(audio_file))
            return {
                'duration': float(info.get('duration', 0)) * 1000,  # 转换为毫秒
                'sample_rate': int(info.get('sample_rate', 0)),
                'channels': int(info.get('channels', 0)),
                'bit_rate': int(info.get('bit_rate', 0)),
                'format': info.get('format_name', ''),
                'size': audio_file.stat().st_size
            }
        except Exception as e:
            logger.error(f"获取音频信息失败: {e}")
            return None


# 测试代码
if __name__ == "__main__":
    # 测试创建目录
    test_dir = AudioUtil.newDirFile("test_output")
    print(f"创建目录: {test_dir}")

    # 测试时间格式转换
    test_time = 123.456
    time_str = AudioUtil.second2VoiceTime(test_time)
    print(f"时间转换: {test_time} -> {time_str}")

    # 测试Unicode转换
    test_unicode = r"\u4e2d\u6587\u6d4b\u8bd5"
    cn_str = AudioUtil.unicodeToCN(test_unicode)
    print(f"Unicode转换: {test_unicode} -> {cn_str}")