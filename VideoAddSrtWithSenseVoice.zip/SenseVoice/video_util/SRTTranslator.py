import hashlib
import json
import re
import time
import urllib.parse
import urllib.request
from typing import List, Optional
from urllib.error import URLError


class SubtitleBlock:
    """字幕块类"""

    def __init__(self, index: int, time_code: str, original_text: str):
        self.index = index
        self.time_code = time_code
        self.original_text = original_text.strip()
        self.translated_text = ""


class SRTTranslator:
    """SRT翻译器"""

    # 百度翻译API配置
    API_KEY = ""
    SECURITY_KEY = ""

    def __init__(self, api_key: str, secret_key: str):
        self.API_KEY = api_key
        self.SECURITY_KEY = secret_key

    @staticmethod
    def read_srt_file(file_path: str) -> List[SubtitleBlock]:
        """读取SRT文件"""
        blocks = []

        # 使用file_read_by_row方法读取文件
        lines = SRTTranslator.file_read_by_row(file_path)

        i = 0
        while i < len(lines):
            # 跳过空行
            if lines[i].strip() == "":
                i += 1
                continue

            try:
                # 第一行：序号
                index = int(lines[i].strip())
                i += 1

                # 第二行：时间码
                if i >= len(lines):
                    break
                time_code = lines[i].strip()
                i += 1

                # 第三行及之后：字幕文本（可能有多行）
                text_builder = []
                while i < len(lines) and lines[i].strip() != "":
                    text_builder.append(lines[i].strip())
                    i += 1

                # 创建字幕块
                if text_builder:
                    blocks.append(SubtitleBlock(index, time_code, "\n".join(text_builder)))

                # 跳过块之间的空行
                while i < len(lines) and lines[i].strip() == "":
                    i += 1

            except ValueError:
                # 如果不是数字，跳过这一行
                i += 1

        return blocks

    @staticmethod
    def file_read_by_row(path: str) -> List[str]:
        """根据行读取文本"""
        lines = []

        try:
            with open(path, 'r', encoding='utf-8') as file:
                lines = file.readlines()
                # 移除每行末尾的换行符
                lines = [line.rstrip('\n') for line in lines]
        except FileNotFoundError:
            print(f"文件未找到: {path}")
        except Exception as e:
            print(f"读取文件时出错: {e}")

        return lines

    @staticmethod
    def md5(input_str: str) -> str:
        """MD5加密"""
        return hashlib.md5(input_str.encode()).hexdigest()

    @staticmethod
    def write_translated_srt(blocks: List[SubtitleBlock], output_path: str,
                             bilingual: bool) -> None:
        """生成翻译后的SRT文件"""
        try:
            with open(output_path, 'w', encoding='utf-8') as writer:
                for i, block in enumerate(blocks):
                    # 序号
                    writer.write(str(i + 1))
                    writer.write('\n')

                    # 时间码
                    writer.write(block.time_code)
                    writer.write('\n')

                    # 字幕文本
                    if bilingual and block.translated_text and block.translated_text.strip():
                        # 双语字幕：原文 + 翻译
                        writer.write(block.original_text)
                        writer.write('\n')
                        writer.write(block.translated_text)
                    elif block.translated_text and block.translated_text.strip():
                        # 纯翻译字幕
                        writer.write(block.translated_text)
                    else:
                        # 没有翻译的情况
                        writer.write(block.original_text)

                    writer.write('\n')

                    # 块之间加空行（除非是最后一个块）
                    if i < len(blocks) - 1:
                        writer.write('\n')

            print(f"文件已保存: {output_path}")

        except Exception as e:
            print(f"写入文件时出错: {e}")

    # bilingual为true双语字幕，false翻译字幕
    @staticmethod
    def translate_srt_file(self, in_srt_path: str, out_srt_path: str,
                           from_lang: str, to_lang: str,
                           bilingual: bool, delay_ms: int) -> None:
        """主翻译方法"""
        print("开始读取字幕文件...")
        # print(f"API_KEY--{self.API_KEY}")
        # print(f"SECURITY_KEY--{self.SECURITY_KEY}")

        blocks = SRTTranslator.read_srt_file(in_srt_path)
        print(f"找到 {len(blocks)} 个字幕块")

        translator = SRTTranslator(self.API_KEY, self.SECURITY_KEY)

        # 翻译每个字幕块
        for i, block in enumerate(blocks):
            # 显示进度
            preview_text = block.original_text
            if len(preview_text) > 50:
                preview_text = preview_text[:50] + "..."

            print(f"正在翻译 {i + 1}/{len(blocks)}: {preview_text}")

            try:
                translated = translator.translate_with_baidu(
                    block.original_text, from_lang, to_lang
                )

                if translated is not None:
                    block.translated_text = translated
                else:
                    print("翻译失败，保留原文")
                    block.translated_text = block.original_text

                # 添加延迟以避免API限制
                if delay_ms > 0 and i < len(blocks) - 1:
                    time.sleep(delay_ms / 1000.0)

            except Exception as e:
                print(f"翻译失败: {e}")
                block.translated_text = block.original_text  # 失败时使用原文

        # 写入翻译后的文件
        SRTTranslator.write_translated_srt(blocks, out_srt_path, bilingual)
        print(f"翻译完成！输出文件: {out_srt_path}")

    def en2zh(self, content: str) -> Optional[str]:
        """英文翻译成中文"""
        return self.translate_with_baidu(content, "en", "zh")

    def zh2en(self, content: str) -> Optional[str]:
        """中文翻译成英文"""
        return self.translate_with_baidu(content, "zh", "en")

    def translate_with_baidu(self, content: str, from_lang: str,
                             to_lang: str) -> Optional[str]:
        """调用百度翻译API"""
        if not content or not content.strip():
            return ""

        try:
            salt = str(int(time.time() * 1000))
            # appid+q+salt+密钥
            sign_str = self.API_KEY + content + salt + self.SECURITY_KEY
            sign = hashlib.md5(sign_str.encode()).hexdigest()

            url = (f"https://fanyi-api.baidu.com/api/trans/vip/translate?"
                   f"q={urllib.parse.quote(content)}&from={from_lang}&to={to_lang}"
                   f"&appid={self.API_KEY}&salt={salt}&sign={sign}")

            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }

            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=10) as response:
                result_str = response.read().decode('utf-8')

            # 处理Unicode转义序列（如\u4e2d\u6587）
            result_str = self.unicode_to_cn(result_str)

            if result_str:
                result_json = json.loads(result_str)

                if "trans_result" in result_json:
                    trans_result = result_json["trans_result"]
                    if trans_result and len(trans_result) > 0:
                        return trans_result[0].get("dst", "")
                elif "error_msg" in result_json:
                    print(f"百度翻译API错误: {result_json['error_msg']}")
                    return None

        except URLError as e:
            print(f"网络请求错误: {e}")
        except json.JSONDecodeError as e:
            print(f"JSON解析错误: {e}")
        except Exception as e:
            print(f"翻译异常: {e}")

        return None

    @staticmethod
    def unicode_to_cn(unicode_str: str) -> str:
        """Unicode转中文"""
        if unicode_str is None:
            return ""

        def replace_unicode(match):
            unicode_code = match.group(2)
            return chr(int(unicode_code, 16))

        pattern = re.compile(r'(\\u([0-9a-fA-F]{4}))')
        return pattern.sub(replace_unicode, unicode_str)

    @staticmethod
    def main():
        """测试主方法"""
        # 测试配置 - 请替换为您的实际API密钥
        SRTTranslator.API_KEY = "your_api_key"
        SRTTranslator.SECURITY_KEY = "your_secret_key"

        translator = SRTTranslator(
            SRTTranslator.API_KEY,
            SRTTranslator.SECURITY_KEY
        )

        try:
            # 测试单个翻译
            print("测试翻译:")
            print(f"英文->中文: {translator.en2zh('Hello, world!')}")
            print(f"中文->英文: {translator.zh2en('你好，世界！')}")

            # 测试SRT文件翻译
            # 注意：这里需要根据实际情况传递参数
            # translate_srt_file(in_srt_path, out_srt_path, from_lang, to_lang, bilingual, delay_ms)

        except Exception as e:
            print(f"测试出错: {e}")


# 如果直接运行此文件，执行测试
if __name__ == "__main__":
    SRTTranslator.main()