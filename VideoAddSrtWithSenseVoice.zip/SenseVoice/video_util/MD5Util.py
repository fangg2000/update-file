import hashlib


class MD5Util:
    HEX_DIGITS = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f"]

    @staticmethod
    def byte_array_to_hex_string(b: bytes) -> str:
        result_sb = []
        for value in b:
            result_sb.append(MD5Util.byte_to_hex_string(value))
        return "".join(result_sb)

    @staticmethod
    def byte_to_hex_string(b: int) -> str:
        n = b
        if n < 0:
            n += 256
        d1 = n // 16
        d2 = n % 16
        return MD5Util.HEX_DIGITS[d1] + MD5Util.HEX_DIGITS[d2]

    @staticmethod
    def md5_encode(origin: str, charsetname: str = "UTF-8") -> str:
        """
        用指定编码进行MD5加密

        Args:
            origin: 原字符串
            charsetname: 字符编码，默认为UTF-8

        Returns:
            str: 加密后字符串
        """
        result_string = origin
        try:
            md = hashlib.md5()
            if charsetname is None or charsetname == "":
                md.update(result_string.encode())
            else:
                md.update(result_string.encode(charsetname))
            result_string = MD5Util.byte_array_to_hex_string(md.digest())
        except Exception:
            # 保持与原Java代码一致，忽略异常
            pass
        return result_string

    # 保持与原Java类相同的接口，提供无参版本
    @staticmethod
    def md5_encode_default(origin: str) -> str:
        """用UTF8编码进行MD5加密"""
        return MD5Util.md5_encode(origin, "UTF-8")


# 为了完全保持与原Java代码相同的使用方式，可以添加以下函数
def md5Encode(origin: str, charsetname: str = None) -> str:
    if charsetname is None:
        return MD5Util.md5_encode_default(origin)
    return MD5Util.md5_encode(origin, charsetname)


# 使用示例
if __name__ == "__main__":
    # 方式1：使用类方法（推荐）
    print(MD5Util.md5_encode("hello"))
    print(MD5Util.md5_encode("hello", "UTF-8"))

    # 方式2：使用独立函数（保持与原Java相同的函数名）
    print(md5Encode("hello"))
    print(md5Encode("hello", "UTF-8"))