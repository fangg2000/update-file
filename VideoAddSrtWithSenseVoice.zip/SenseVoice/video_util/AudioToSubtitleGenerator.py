import json
import os
import re
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
import requests
from dataclasses import dataclass

from funasr import AutoModel

@dataclass
class TimeSegment:
    """时间片段（包含开始时间和结束时间）"""
    file_number: int
    start_time: str
    end_time: str


@dataclass
class SubtitleEntry:
    """字幕条目"""
    index: int
    start_time: str
    end_time: str
    text: str


class AudioToSubtitleGenerator:

    @staticmethod
    def generate_subtitle_from_audio(
            audio_dir_path: str,
            time_srt_path: str,
            back_map: Dict[str, int],
            max_retries: int = 3,
            model_in: AutoModel = None
    ) -> Optional[str]:
        """
        根据音频目录和时间信息生成SRT字幕文件

        Args:
            audio_dir_path: 音频目录路径（包含切割后的音频文件）
            time_srt_path: 时间文件路径（time.srt，格式：文件序号#开始时间#结束时间）
            back_map: 进度回调字典
            max_retries: 最大重试次数（默认3次）
            model_in: 音频到文本推理模型

        Returns:
            输出SRT文件路径，失败返回None
        """
        # 输出字幕文件
        output_srt_path = os.path.join(audio_dir_path, "original.srt")
        progress = 0.0

        if max_retries <= 0:
            max_retries = 3

        try:
            # 1. 读取时间文件（格式：10001#00:00:10.322#00:00:20.647）
            time_segments = AudioToSubtitleGenerator._parse_time_srt_file(time_srt_path)

            # 2. 获取音频文件列表（按序号排序）
            audio_files = AudioToSubtitleGenerator._get_audio_files(audio_dir_path)

            # 3. 为每个时间片段生成字幕
            subtitle_entries = []

            for i, segment in enumerate(time_segments):
                sum_size = len(time_segments)

                # 获取对应的音频文件
                audio_file_path = audio_files.get(segment.file_number)
                if audio_file_path is None:
                    print(f"警告: 未找到文件序号 {segment.file_number} 对应的音频文件")
                    continue

                # 调用Python接口获取文本，传递model_in参数
                text = AudioToSubtitleGenerator._transcribe_audio(
                    audio_file_path,
                    max_retries,
                    model_in  # 传递model_in参数
                )

                if text and text.strip():
                    entry = SubtitleEntry(
                        index=i + 1,
                        start_time=AudioToSubtitleGenerator._format_time_for_srt(segment.start_time),
                        end_time=AudioToSubtitleGenerator._format_time_for_srt(segment.end_time),
                        text=text.strip()
                    )
                    subtitle_entries.append(entry)

                    text_preview = text[:50] + "..." if len(text) > 50 else text
                    print(f"处理完成: {segment.file_number} "
                          f"[{segment.start_time} --> {segment.end_time}] -> {text_preview}")
                else:
                    print(f"警告: 文件序号 {segment.file_number} 音频转文本失败")

                # 处理进度
                progress = min(100.0, (i / sum_size) * 100)
                progress = round(progress * 100.0) / 100.0
                back_map["progress"] = int(progress)

            # 4. 生成SRT文件
            AudioToSubtitleGenerator._generate_srt_file(subtitle_entries, output_srt_path)

            print(f"字幕生成完成! 共生成 {len(subtitle_entries)} 条字幕")
            print(f"保存路径: {output_srt_path}")

        except Exception as e:
            print(f"处理过程中出错: {e}")
            import traceback
            traceback.print_exc()
            return None
        finally:
            back_map["pro_over"] = 1

        return output_srt_path

    @staticmethod
    def _parse_time_srt_file(time_srt_path: str) -> List[TimeSegment]:
        """
        解析时间文件（新格式：10001#00:00:10.322#00:00:20.647）
        """
        segments = []

        try:
            with open(time_srt_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()

            for line in lines:
                line = line.strip()
                if line:
                    parts = line.split('#')
                    if len(parts) == 3:
                        try:
                            file_number = int(parts[0])
                            start_time = parts[1]
                            end_time = parts[2]
                            segments.append(TimeSegment(file_number, start_time, end_time))
                        except ValueError:
                            print(f"警告: 无法解析行: {line}")
                    else:
                        print(f"警告: 行格式不正确，应为3部分，实际为 {len(parts)} 部分: {line}")
        except IOError as e:
            print(f"读取时间文件失败: {e}")
            raise

        # 按文件序号排序
        segments.sort(key=lambda x: x.file_number)

        print(f"解析到 {len(segments)} 个时间片段")
        return segments

    @staticmethod
    def _get_audio_files(audio_dir_path: str) -> Dict[int, str]:
        """
        获取音频文件列表
        """
        audio_files = {}
        audio_dir = Path(audio_dir_path)

        if audio_dir.exists() and audio_dir.is_dir():
            # 支持的音频文件扩展名
            audio_extensions = {'.wav', '.mp3', '.flac'}

            for file_path in audio_dir.iterdir():
                if file_path.suffix.lower() in audio_extensions:
                    try:
                        # 从文件名中提取数字（如 10001.wav -> 10001）
                        name = file_path.stem
                        # 使用正则表达式提取文件名中的数字
                        match = re.search(r'(\d+)', name)
                        if match:
                            number_str = match.group(1)
                            file_number = int(number_str)
                            audio_files[file_number] = str(file_path.absolute())
                    except ValueError:
                        # 忽略无法解析的文件
                        print(f"警告: 无法从文件名提取数字: {file_path.name}")
        else:
            print(f"错误: 音频目录不存在或不是目录: {audio_dir_path}")

        print(f"找到 {len(audio_files)} 个音频文件")
        return audio_files

    @staticmethod
    def _transcribe_audio(
            audio_path: str,
            max_retries: int,
            model_in: AutoModel = None
    ) -> Optional[str]:
        """
        调用Python接口进行音频转文本

        Args:
            audio_path: 音频文件路径
            api_url: API接口URL
            max_retries: 最大重试次数
            model_in: 模型
        """
        text = None
        retry_count = 0

        while retry_count < max_retries:
            try:
                text = AudioToSubtitleGenerator._call_python_api(
                    audio_path,
                    model_in  # 传递model_in参数
                )
                if text and text.strip():
                    break
            except Exception as e:
                print(f"第 {retry_count + 1} 次调用失败: {e}")
                retry_count += 1

                if retry_count < max_retries:
                    time.sleep(2)  # 等待2秒后重试

        if not text or not text.strip():
            print(f"警告: 音频转文本失败: {audio_path}")

        return text

    @staticmethod
    def _call_python_api(
            audio_path: str,
            model_in: AutoModel
    ) -> Optional[str]:
        """
        调用Python API

        Args:
            audio_path: 音频文件路径
            model_in: 模型参数，将被传递到API请求中
        """

        # 如果提供了model_in参数，添加到请求体中
        if model_in is None:
            raise Exception(f"模型不能为空")

        print(f'开始音频推理...')

        try:
            response = AudioToSubtitleGenerator.t2a_service(model_in, audio_path)

            if response.get("code") == 1:
                return response.get("data")
            else:
                raise Exception(f"HTTP错误: {response.get('msg')}")

        except requests.RequestException as e:
            raise Exception(f"请求失败: {e}")

    @staticmethod
    def _format_time_for_srt(time_str: str) -> str:
        """
        将时间格式转换为SRT格式（HH:MM:SS,mmm）
        """
        # 将 HH:MM:SS.mmm 转换为 HH:MM:SS,mmm
        return time_str.replace('.', ',')

    @staticmethod
    def _generate_srt_file(entries: List[SubtitleEntry], output_path: str) -> None:
        """
        生成SRT文件
        """
        try:
            with open(output_path, 'w', encoding='utf-8') as writer:
                for entry in entries:
                    writer.write(f"{entry.index}\n")
                    writer.write(f"{entry.start_time} --> {entry.end_time}\n")
                    writer.write(f"{entry.text}\n")
                    writer.write("\n")  # 空行分隔
        except IOError as e:
            print(f"写入SRT文件失败: {e}")
            raise

    @staticmethod
    def batch_process_audio_directories(
            base_dir_path: str,
            back_map: Dict[str, int],
            model_in: Any = None
    ) -> None:
        """
        批量处理多个音频目录

        Args:
            base_dir_path: 基础目录，包含多个cut_xxx子目录
            back_map: 进度回调字典
            model_in: 模型参数
        """
        base_dir = Path(base_dir_path)
        if not base_dir.exists() or not base_dir.is_dir():
            print(f"错误: 基础目录不存在: {base_dir_path}")
            return

        # 查找所有cut_xxx子目录
        sub_dirs = [d for d in base_dir.iterdir() if d.is_dir() and d.name.startswith("cut_")]

        if not sub_dirs:
            print("未找到任何cut_xxx子目录")
            return

        print(f"找到 {len(sub_dirs)} 个目录需要处理")

        for sub_dir in sub_dirs:
            print(f"\n开始处理目录: {sub_dir.name}")

            time_srt_path = sub_dir / "time.srt"
            output_srt_path = sub_dir / "subtitle.srt"

            # 检查时间文件是否存在
            if not time_srt_path.exists():
                print(f"跳过: 未找到时间文件: {time_srt_path}")
                continue

            try:
                AudioToSubtitleGenerator.generate_subtitle_from_audio(
                    str(sub_dir),
                    str(time_srt_path),
                    back_map,
                    3,
                    model_in  # 传递model_in参数
                )
            except Exception as e:
                print(f"处理目录 {sub_dir.name} 时出错: {e}")
                import traceback
                traceback.print_exc()

        print("\n批量处理完成!")

    @staticmethod
    def generate_subtitle_from_audio_simple(
            audio_dir_path: str,
            time_srt_path: str,
            back_map: Dict[str, int],
            model_in: Any = None
    ) -> Optional[str]:
        """
        简化调用方法（使用默认重试次数）
        """
        return AudioToSubtitleGenerator.generate_subtitle_from_audio(
            audio_dir_path, time_srt_path, back_map, 3, model_in
        )

    # 定义返回对象(字符串)
    def result_entity(code:int=1, msg:str='', data:Any=None):
        if code == -1:
            msg = '操作异常' if msg == '' else msg
        elif code == 0:
            msg = '操作失败' if msg == '' else msg
        elif code == 2:
            msg = '字段不能为空' if msg == '' else msg
        else:
            msg = '操作成功' if msg == '' else msg

        if data == None:
            return {'msg': msg, 'code': code}

        return {'msg': msg, 'code': code, 'data': data}

    @staticmethod
    def t2a_service(model_in: AutoModel, audio_path: str):
        # global model, tokenizer

        try:
            # en
            res = model_in.generate(
                input=audio_path,
                cache={},
                language="auto",  # "zh", "en", "yue", "ja", "ko", "nospeech"
                use_itn=True,
                batch_size_s=60,
                merge_vad=True,
                merge_length_s=15,
            )

            # print(res[0]["text"])
            # text = rich_transcription_postprocess(res[0]["text"])
            text = re.sub(r'<\|.*?\|>', '', res[0]["text"])
            # print(text)
            return AudioToSubtitleGenerator.result_entity(data=text)
        except IOError as e:
            print(f'音频到文本推理异常：{e}')
            pass

        return AudioToSubtitleGenerator.result_entity(0, '音频到文本推理失败')



# 示例使用方法
if __name__ == "__main__":
    try:
        # 方式1: 处理单个目录
        audio_dir_path = "/home/fangg/tmp/cut01/cut_626b65"  # 切割后的音频目录
        time_srt_path = "/home/fangg/tmp/cut01/cut_626b65/time.srt"  # 时间文件（新格式）
        python_api_url = "http://127.0.0.1:8008/sense_voice/stt"  # Python接口
        back_map = {}  # 进度回调字典

        # 定义模型参数（示例）
        model_in = None

        # 生成字幕
        result = AudioToSubtitleGenerator.generate_subtitle_from_audio(
            audio_dir_path, time_srt_path, back_map, 3, model_in
        )

        if result:
            print(f"\n字幕文件已生成: {result}")

        # 方式2: 批量处理多个目录
        # base_dir = "D:/audio"
        # model_in = "whisper-base"
        # AudioToSubtitleGenerator.batch_process_audio_directories(base_dir, {}, model_in)

    except Exception as e:
        import traceback

        traceback.print_exc()