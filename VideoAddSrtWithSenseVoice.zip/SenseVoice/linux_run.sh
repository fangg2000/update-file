#!/bin/bash
echo "Starting SenseVoice..."

# 直接启动
env/bin/python VideoWebUI.py
