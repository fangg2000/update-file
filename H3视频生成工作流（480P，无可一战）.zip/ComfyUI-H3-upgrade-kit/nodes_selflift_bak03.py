"""可串联的 SelfLift K采与解码后的音画拼接。"""

import torch
import torch.nn.functional as F
import torchaudio.functional
import os
import json
import folder_paths
import time
import pickle
import base64

import comfy.model_management as mm
from comfy.nested_tensor import NestedTensor

import comfy.samplers
from comfy_extras.nodes_custom_sampler import BasicScheduler

from .nodes_latent_upscale import list_upscale_weights
#from .selflift_sampling import SEGMENT, progressive_sample
from .selflift_sampling import LOW_CARRY, SEGMENT, progressive_sample
from safetensors import safe_open
from safetensors.torch import load_file, save_file


def _unique_safetensors_path(path):
    if not os.path.exists(path):
        return path
    base, ext = os.path.splitext(path)
    i = 1
    while True:
        candidate = f"{base}_{i:05d}{ext}"
        if not os.path.exists(candidate):
            return candidate
        i += 1

# 保留原有 imports 和 _unique_safetensors_path()
# 替换原来的 _resolve_device、save_latent_safetensors、load_latent_safetensors
# 并新增以下两个递归辅助函数。

_LATENT_FORMAT_V3 = "h3kit_selflift_latent_v3"
_LATENT_STRUCTURE_KEY = "__h3kit_structure__"
_LATENT_TENSOR_PREFIX = "__h3kit_tensor_"
_LATENT_NODE_TAG = "__h3kit_latent_node_v3__"


def _resolve_device(device_str):
    """恢复原设备；设备不可用时回退至 ComfyUI 的 intermediate_device。"""
    if not device_str:
        return mm.intermediate_device()

    try:
        dev = torch.device(device_str)

        if dev.type == "cuda":
            if not torch.cuda.is_available():
                return mm.intermediate_device()

            # 不仅检查 CUDA 是否可用，也检查原 GPU 索引是否存在。
            if (
                dev.index is not None
                and dev.index >= torch.cuda.device_count()
            ):
                return mm.intermediate_device()

        if dev.type == "mps":
            mps_backend = getattr(torch.backends, "mps", None)
            if mps_backend is None or not mps_backend.is_available():
                return mm.intermediate_device()

        return dev

    except Exception:
        return mm.intermediate_device()


def _pack_latent_tree(value, tensors, tensor_info, seen_tensors):
    """
    递归拆分 LATENT 数据结构。

    所有常见容器中的 Tensor 和 NestedTensor 均独立存入 safetensors。
    返回的结构描述保留原有容器关系，并以引用指向对应张量。
    """

    # 必须优先判断 NestedTensor，不能让它进入普通 Tensor 分支。
    if isinstance(value, NestedTensor):
        components = value.unbind()

        return (
            _LATENT_NODE_TAG,
            "nested_tensor",
            tuple(
                _pack_latent_tree(
                    item, tensors, tensor_info, seen_tensors
                )
                for item in components
            ),
        )

    if isinstance(value, torch.Tensor):
        if value.layout != torch.strided:
            raise TypeError(
                "暂不支持保存非 strided 布局的 Tensor："
                f"layout={value.layout}"
            )

        if value.is_quantized:
            raise TypeError(
                "暂不支持直接保存量化 Tensor，请先将其转换为普通 Tensor。"
            )

        # 如果同一个 Tensor 对象被多次引用，只保存一次。
        object_id = id(value)

        if object_id in seen_tensors:
            tensor_key = seen_tensors[object_id]
        else:
            tensor_key = (
                f"{_LATENT_TENSOR_PREFIX}{len(tensors):08d}"
            )

            # safetensors 使用 CPU、连续存储的张量。
            # 这会改变存储设备和内存布局，但不会改变张量的数值、
            # 形状或 dtype。
            saved_tensor = (
                value.detach()
                .to(device="cpu")
                .contiguous()
                .clone()
            )

            tensors[tensor_key] = saved_tensor

            tensor_info[tensor_key] = {
                "device": str(value.device),
                "requires_grad": bool(value.requires_grad),
            }

            seen_tensors[object_id] = tensor_key

        return (_LATENT_NODE_TAG, "tensor", tensor_key)

    # 保留字典中的原有键值及顺序。
    if isinstance(value, dict):
        items = [
            (
                _pack_latent_tree(
                    key, tensors, tensor_info, seen_tensors
                ),
                _pack_latent_tree(
                    item, tensors, tensor_info, seen_tensors
                ),
            )
            for key, item in value.items()
        ]

        if type(value) is dict:
            return (_LATENT_NODE_TAG, "dict", items)

        # 兼容常见 dict 子类，例如 OrderedDict、defaultdict。
        has_default_factory = hasattr(value, "default_factory")
        default_factory = (
            value.default_factory if has_default_factory else None
        )

        return (
            _LATENT_NODE_TAG,
            "dict_subclass",
            type(value),
            has_default_factory,
            default_factory,
            items,
        )

    if isinstance(value, list):
        items = [
            _pack_latent_tree(
                item, tensors, tensor_info, seen_tensors
            )
            for item in value
        ]

        if type(value) is list:
            return (_LATENT_NODE_TAG, "list", items)

        return (
            _LATENT_NODE_TAG,
            "list_subclass",
            type(value),
            items,
        )

    if isinstance(value, tuple):
        items = tuple(
            _pack_latent_tree(
                item, tensors, tensor_info, seen_tensors
            )
            for item in value
        )

        # namedtuple 需要额外保存其类型。
        if hasattr(value, "_fields"):
            return (
                _LATENT_NODE_TAG,
                "namedtuple",
                type(value),
                items,
            )

        return (_LATENT_NODE_TAG, "tuple", items)

    if isinstance(value, set):
        items = [
            _pack_latent_tree(
                item, tensors, tensor_info, seen_tensors
            )
            for item in value
        ]
        return (_LATENT_NODE_TAG, "set", items)

    if isinstance(value, frozenset):
        items = [
            _pack_latent_tree(
                item, tensors, tensor_info, seen_tensors
            )
            for item in value
        ]
        return (_LATENT_NODE_TAG, "frozenset", items)

    # 普通数值、字符串、None、对象等作为非张量值保留。
    # 外层结构在生成结构描述时统一 pickle 序列化。
    return (_LATENT_NODE_TAG, "value", value)


def _unpack_latent_tree(node, tensors, tensor_info, restored_tensors):
    """递归重建保存时的 LATENT 结构。"""

    if not (
        isinstance(node, tuple)
        and len(node) >= 2
        and node[0] == _LATENT_NODE_TAG
    ):
        return node

    node_type = node[1]

    if node_type == "value":
        return node[2]

    if node_type == "tensor":
        tensor_key = node[2]

        # 相同的张量引用只恢复一次，以尽量保留引用关系。
        if tensor_key in restored_tensors:
            return restored_tensors[tensor_key]

        tensor = tensors.get(tensor_key)
        if tensor is None:
            raise ValueError(
                f"latent 文件缺少张量数据：{tensor_key}"
            )

        info = tensor_info.get(tensor_key, {})
        device = _resolve_device(info.get("device"))

        restored = tensor.to(device=device)

        # requires_grad 可以恢复，但原有 autograd 计算图不能通过
        # safetensors 一并恢复；普通 ComfyUI latent 通常不需要计算图。
        if (
            info.get("requires_grad", False)
            and (
                restored.is_floating_point()
                or restored.is_complex()
            )
        ):
            restored.requires_grad_(True)

        restored_tensors[tensor_key] = restored
        return restored

    if node_type == "nested_tensor":
        components = [
            _unpack_latent_tree(
                item, tensors, tensor_info, restored_tensors
            )
            for item in node[2]
        ]
        return NestedTensor(components)

    if node_type == "dict":
        return {
            _unpack_latent_tree(
                key, tensors, tensor_info, restored_tensors
            ): _unpack_latent_tree(
                item, tensors, tensor_info, restored_tensors
            )
            for key, item in node[2]
        }

    if node_type == "dict_subclass":
        cls = node[2]
        has_default_factory = node[3]
        default_factory = node[4]
        items = node[5]

        try:
            if has_default_factory:
                result = cls(default_factory)
            else:
                result = cls()
        except Exception:
            result = {}

        for key, item in items:
            restored_key = _unpack_latent_tree(
                key, tensors, tensor_info, restored_tensors
            )
            restored_item = _unpack_latent_tree(
                item, tensors, tensor_info, restored_tensors
            )
            result[restored_key] = restored_item

        return result

    if node_type == "list":
        return [
            _unpack_latent_tree(
                item, tensors, tensor_info, restored_tensors
            )
            for item in node[2]
        ]

    if node_type == "list_subclass":
        cls = node[2]
        items = [
            _unpack_latent_tree(
                item, tensors, tensor_info, restored_tensors
            )
            for item in node[3]
        ]

        try:
            return cls(items)
        except Exception:
            return items

    if node_type == "tuple":
        return tuple(
            _unpack_latent_tree(
                item, tensors, tensor_info, restored_tensors
            )
            for item in node[2]
        )

    if node_type == "namedtuple":
        cls = node[2]
        items = [
            _unpack_latent_tree(
                item, tensors, tensor_info, restored_tensors
            )
            for item in node[3]
        ]
        return cls(*items)

    if node_type == "set":
        return {
            _unpack_latent_tree(
                item, tensors, tensor_info, restored_tensors
            )
            for item in node[2]
        }

    if node_type == "frozenset":
        return frozenset(
            _unpack_latent_tree(
                item, tensors, tensor_info, restored_tensors
            )
            for item in node[2]
        )

    raise ValueError(f"无法识别的 latent 结构节点：{node_type}")


def save_latent_safetensors(latent, prefix):
    """
    递归保存完整 LATENT。

    新版 v3：
    - 所有可识别的 Tensor 独立保存在 safetensors 张量区。
    - 保存整个 LATENT 的嵌套结构描述。
    - 保存每个张量的原始 device 和 requires_grad 信息。
    - 兼容 NestedTensor、字典、列表、元组等常见容器。
    """

    prefix = (prefix or "").strip()
    if not prefix:
        return None

    if not isinstance(latent, dict):
        raise TypeError(
            f"期望 LATENT 为 dict，实际类型为 {type(latent).__name__}"
        )

    if prefix.endswith(".safetensors"):
        prefix = prefix[:-len(".safetensors")]

    out_dir = folder_paths.get_output_directory()

    parts = [
        part
        for part in prefix.replace("\\", "/").split("/")
        if part not in ("", ".", "..")
    ]

    if not parts:
        return None

    path = (
        os.path.join(
            out_dir,
            *parts[:-1],
            f"{parts[-1]}_{int(time.time())}",
        )
        + ".safetensors"
    )

    os.makedirs(os.path.dirname(path), exist_ok=True)
    path = _unique_safetensors_path(path)

    tensors = {}
    tensor_info = {}
    seen_tensors = {}

    # 递归处理整个 LATENT 字典，而不是只遍历顶层值。
    structure = _pack_latent_tree(
        latent,
        tensors,
        tensor_info,
        seen_tensors,
    )

    # 将结构描述存入 safetensors 的张量区，避免把完整结构塞进
    # metadata 字符串。普通非张量值通过 pickle 保留其 Python 类型。
    structure_bytes = pickle.dumps(
        structure,
        protocol=pickle.HIGHEST_PROTOCOL,
    )

    tensors[_LATENT_STRUCTURE_KEY] = (
        torch.frombuffer(
            bytearray(structure_bytes),
            dtype=torch.uint8,
        )
        .clone()
        .contiguous()
    )

    metadata = {
        "format": _LATENT_FORMAT_V3,
        "tensor_info": json.dumps(
            tensor_info,
            ensure_ascii=False,
        ),
    }

    save_file(tensors, path, metadata=metadata)

    print(
        f"[H3Kit SelfLift] saved complete latent -> {path}; "
        f"tensor_count={len(tensor_info)}"
    )

    return path


def load_latent_safetensors(file_path):
    """
    加载 SelfLift LATENT。

    v3：递归重建全部已支持的容器与张量。
    v2/旧格式：沿用原来的恢复流程，同时修复 samples_key 未使用的问题。
    """

    file_path = (file_path or "").strip()

    if not file_path:
        raise ValueError("请指定要恢复的 .safetensors 文件路径。")

    if not os.path.isabs(file_path):
        file_path = os.path.join(
            folder_paths.get_output_directory(),
            file_path,
        )

    if not file_path.endswith(".safetensors"):
        file_path += ".safetensors"

    if not os.path.exists(file_path):
        raise ValueError(f"latent 文件不存在：{file_path}")

    with safe_open(file_path, framework="pt") as f:
        meta = f.metadata() or {}

    data = load_file(file_path)

    # ---------------------------------------------------------
    # 新版 v3：递归恢复完整结构
    # ---------------------------------------------------------
    if meta.get("format") == _LATENT_FORMAT_V3:
        structure_tensor = data.pop(
            _LATENT_STRUCTURE_KEY,
            None,
        )

        if structure_tensor is None:
            raise ValueError(
                "v3 latent 文件缺少结构描述，无法完整恢复。"
            )

        structure_bytes = (
            structure_tensor
            .detach()
            .cpu()
            .contiguous()
            .numpy()
            .tobytes()
        )

        try:
            structure = pickle.loads(structure_bytes)
        except Exception as exc:
            raise ValueError(
                f"latent 结构描述无法解析：{exc}"
            ) from exc

        try:
            tensor_info = json.loads(
                meta.get("tensor_info", "{}")
            )
        except Exception:
            tensor_info = {}

        restored = _unpack_latent_tree(
            structure,
            data,
            tensor_info,
            restored_tensors={},
        )

        if not isinstance(restored, dict):
            raise ValueError(
                "恢复后的顶层结构不是 dict，与 ComfyUI LATENT 格式不符。"
            )

        return restored

    # ---------------------------------------------------------
    # 旧版兼容：读取已有 v2 / 旧格式文件
    # ---------------------------------------------------------
    result = {}

    # 恢复旧版非张量数据。
    non_tensor_raw = meta.get("non_tensor_data")

    if non_tensor_raw:
        try:
            non_tensor_data = pickle.loads(
                base64.b64decode(non_tensor_raw)
            )
        except Exception as exc:
            raise ValueError(
                f"旧版 latent 的非张量数据无法恢复：{exc}"
            ) from exc

        result.update(non_tensor_data)

    # 恢复旧版设备映射。
    devices = {}
    devices_raw = meta.get("devices")

    if devices_raw:
        try:
            devices = json.loads(devices_raw)
        except Exception:
            devices = {}

    def restore_legacy_device(tensor, key):
        dev_str = devices.get(key)

        if dev_str:
            device = _resolve_device(dev_str)
        else:
            device = mm.intermediate_device()

        return tensor.to(device=device)

    samples_nested = meta.get("samples_nested") == "true"
    samples_key = meta.get("samples_key") or "samples"

    if samples_nested:
        video = data.get("__samples_video__")
        audio = data.get("__samples_audio__")

        if video is None or audio is None:
            raise ValueError(
                "旧版 latent 中缺少 NestedTensor 的 video/audio。"
            )

        video = restore_legacy_device(
            video, "__samples_video__"
        )
        audio = restore_legacy_device(
            audio, "__samples_audio__"
        )

        # 修正旧实现：恢复到保存时记录的真实键名。
        result[samples_key] = NestedTensor([video, audio])

    else:
        if samples_key in data:
            samples = data[samples_key]
            result[samples_key] = restore_legacy_device(
                samples, samples_key
            )
        elif "samples" in data:
            samples = data["samples"]
            result["samples"] = restore_legacy_device(
                samples, "samples"
            )
        else:
            raise ValueError(
                "旧版 latent 文件中缺少 samples。"
            )

    # 恢复其余张量键，不能只恢复 samples。
    reserved_keys = {
        "__samples_video__",
        "__samples_audio__",
    }

    for key, tensor in data.items():
        if key in reserved_keys:
            continue

        if key in result and key == samples_key:
            continue

        result[key] = restore_legacy_device(tensor, key)

    return result

class H3KitSelfLiftSampler:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "model": ("MODEL",),
                "positive": ("CONDITIONING",),
                "negative": ("CONDITIONING",),
                "latent_image": ("LATENT", {"tooltip": "本段目标高清 H3 音视频 latent；长度代表本段新增帧数。续接时只在头部增加17帧的整数倍上下文，拼接后保留原定新增长度，不补视频尾帧。"}),
                "seed": ("INT", {"default": 0, "min": 0, "max": 0xffffffffffffffff, "control_after_generate": True}),
                "steps": ("INT", {"default": 8, "min": 2, "max": 10000}),
                "cfg": ("FLOAT", {"default": 1.0, "min": 0, "max": 100, "step": 0.1}),
                "sampler_name": (["euler"], {"default": "euler",
                    "tooltip": "当前 SelfLift 交接使用 Euler 更新公式，只支持标准 euler；其他算法需要单独适配交接与历史状态。"}),
                "scheduler": (comfy.samplers.SCHEDULER_NAMES, {"default": "simple"}),
                "denoise": ("FLOAT", {"default": 1.0, "min": 0.0, "max": 1.0, "step": 0.01,
                    "tooltip": "降噪强度，仅在未连接外部 sigmas 时生效。低于 1 时保留更多输入 latent 内容；0 时直接返回输入，不执行二采或续接。"}),
                "high_resolution_steps": ("INT", {"default": 2, "min": 1, "max": 9999,
                    "tooltip": "总步数中的高清部分。8 步、高清 2 步表示低清 6 步＋高清 2 步；固定使用 Euler。"}),
                "lowres_scale": ("FLOAT", {"default": 0.5, "min": 0.25, "max": 1.0, "step": 0.05,
                    "tooltip": "低清宽高比例。前后段须使用相同设置；整段仍使用latent放大，接context_vae时仅把实际尾部画面缩小后编码为低清上下文。"}),
                "upscale_weights": (list_upscale_weights(),),
                "overlap_frames": ("INT", {"default": 17, "min": 17, "max": 3587, "step": 17,
                    "tooltip": "额外增加的头部上下文：17、34、51……帧，对应前段尾部的5、10、15……个latent时间步；不占用本段新增帧数。"}),
                "continue_audio": ("BOOLEAN", {"default": True,
                    "tooltip": "续接前段尾音，最后 8 个音频 token 平滑释放。已锁定的输入音轨优先。"}),
            },
            "optional": {
                "previous_latent": ("LATENT", {"tooltip": "直接接前一个 H3Kit SelfLift K采的 sampled_latent；同时携带低清和高清状态。"}),
                "sigmas": ("SIGMAS", {"tooltip": "可选外部调度；连接后取代 steps/scheduler/denoise，总步数和降噪强度由外部调度决定。"}),
                "spatial_tiles": ("BOOLEAN", {"default": False,
                    "label_on": "高清采样分块：开启", "label_off": "高清采样分块：关闭",
                    "tooltip": "仅对 SelfLift 高清采样阶段沿长边重叠分块，支持视频/音频遮罩及固定上下文续接。不影响 latent 放大或 VAE 解码。"}),
                "minimum_tiles": ("INT", {"default": 4, "min": 2, "max": 8,
                    "tooltip": "高清采样的最少分块数，按显存预算增加到最多 8 块；小画面受网格限制可能更少。音频取第一块预测，不支持 ControlNet。"}),
                "context_vae": ("VAE", {"tooltip": "连接H3视频VAE，以前段最终高清画面作为统一来源：原尺寸编码高清上下文，缩小画面后编码低清上下文，供锁定前缀和连续运动引导使用。不连接则沿用原生latent尾部；只处理上下文，不做整段像素校正。"}),
                "previous_frames": ("IMAGE", {"tooltip": "可选：前段实际解码画面，配合context_vae避免再次解码高清前段；不连接则自动解码。"}),
                "latent_save_prefix": ("STRING", {
                    "default": "",
                    "multiline": False,
                    "tooltip": "非空时把 sampled_latent 保存到 output/<前缀>.safetensors；空则不保存。"
                }),
            },
        }

    RETURN_TYPES = ("LATENT",)
    RETURN_NAMES = ("sampled_latent",)
    FUNCTION = "sample"
    CATEGORY = "H3 Upgrade Kit/采样"
    DESCRIPTION = "低清采样→学习型latent放大→高清续采。前段输出接previous_latent；两个阶段各自锁定连续重叠区并加入整段运动引导，单张首帧转为外观参考；放大后按高清尾部校正新画面。解码后接‘SelfLift续接音画拼接’。"

    def sample(self, model, positive, negative, latent_image, seed, steps, cfg, scheduler,
               high_resolution_steps, lowres_scale, upscale_weights, overlap_frames,
               continue_audio, previous_latent=None, sigmas=None, denoise=1.0, sampler_name="euler",
               spatial_tiles=False, minimum_tiles=4, context_vae=None, previous_frames=None, latent_save_prefix=""):
        if sigmas is None:
            if denoise == 0:
                result = latent_image
                if latent_save_prefix:
                    save_latent_safetensors(result, latent_save_prefix)
                return (result,)
            sigmas = BasicScheduler.execute(model, scheduler, steps, denoise)[0]

        result = progressive_sample(
            model, positive, negative, latent_image, sigmas, seed, cfg,
            high_resolution_steps, lowres_scale, upscale_weights,
            previous_latent, overlap_frames, continue_audio, sampler_name=sampler_name,
            spatial_tiles=spatial_tiles, minimum_tiles=minimum_tiles,
            context_vae=context_vae, previous_frames=previous_frames
        )

        if latent_save_prefix:
            save_latent_safetensors(result, latent_save_prefix)

        return (result,)


def fit_audio(waveform, length):
    if waveform.shape[-1] < length:
        return F.pad(waveform, (0, length - waveform.shape[-1]))
    return waveform[..., :length]


class H3KitSelfLiftAVJoin:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "sampled_latent": ("LATENT", {"tooltip": "本段 SelfLift K采输出，用于读取实际重叠和音频续接信息。"}),
                "decoded_frames": ("IMAGE", {"tooltip": "本段完整解码画面，不要预先裁掉重叠。"}),
            },
            "optional": {
                "decoded_audio": ("AUDIO",),
                "previous_frames": ("IMAGE", {"tooltip": "前一拼接节点的 images，或第一段完整解码画面。"}),
                "previous_audio": ("AUDIO", {"tooltip": "与 previous_frames 同步的累积音频；多段视频可连续串联。"}),
            },
        }

    RETURN_TYPES = ("IMAGE", "AUDIO")
    RETURN_NAMES = ("images", "audio")
    FUNCTION = "join"
    CATEGORY = "H3 Upgrade Kit/视频续接"
    DESCRIPTION = "裁掉17帧整数倍的重复前缀，保留本段原定新增帧数；启用 Soft AV 时用后段过渡音频替换前段对应尾音。按24fps对齐音频长度。"

    def join(self, sampled_latent, decoded_frames, decoded_audio=None, previous_frames=None, previous_audio=None):
        info = sampled_latent.get(SEGMENT)
        if info is None:
            raise ValueError("请连接 H3Kit SelfLift K采的原始输出，以读取续接信息。")
        if decoded_frames.shape[0] != info["frames"]:
            raise ValueError("解码帧数与采样 latent 不匹配，请连接本段未经裁剪的完整画面。")
        overlap = info["overlap_frames"]
        joined = previous_frames is not None
        if joined and not overlap:
            raise ValueError("本段未接入前段 latent；拼接前请先连接 K采的 previous_latent。")
        if previous_audio is not None and not joined:
            raise ValueError("previous_audio 需要匹配的 previous_frames。")
        delivery = info["delivery_frames"]
        end = overlap + delivery
        if delivery <= 0 or end > info["frames"]:
            raise ValueError("本段有效长度与采样帧数不匹配。")
        frames = decoded_frames[overlap:end].clone()
        if joined:
            if previous_frames.shape[0] < overlap:
                raise ValueError("前段画面短于重叠区。")
            frames = torch.cat((previous_frames, frames.to(previous_frames)), dim=0)
        if decoded_audio is None and previous_audio is None:
            return frames, None
        source = decoded_audio if decoded_audio is not None else previous_audio
        sr = source["sample_rate"]
        template = source["waveform"]
        current_length = round(end * sr / 24)
        current = (decoded_audio["waveform"] if decoded_audio is not None
                   else template.new_zeros((*template.shape[:-1], current_length)))
        current = fit_audio(current, current_length)
        cut = round(overlap * sr / 24)
        if joined:
            prior_length = round(previous_frames.shape[0] * sr / 24)
            if previous_audio is None:
                prior = template.new_zeros((*template.shape[:-1], prior_length))
            else:
                prior = previous_audio["waveform"].to(template)
                if previous_audio["sample_rate"] != sr:
                    prior = torchaudio.functional.resample(prior, previous_audio["sample_rate"], sr)
                if prior.shape[:-1] != current.shape[:-1]:
                    raise ValueError("前后段音频的批次和声道数必须一致。")
                prior = fit_audio(prior, prior_length)
            if info["soft_audio"] and decoded_audio is not None and previous_audio is not None:
                waveform = torch.cat((prior[..., :prior_length - cut], current), dim=-1)
            else:
                waveform = torch.cat((prior, current[..., cut:]), dim=-1)
        else:
            waveform = current[..., cut:]
        waveform = fit_audio(waveform, round(frames.shape[0] * sr / 24)).clone()
        return frames, {"waveform": waveform, "sample_rate": sr}


class H3KitSelfLiftLatentRestore:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "file_path": ("STRING", {
                    "default": "",
                    "multiline": False,
                    "tooltip": "要恢复的 .safetensors 文件；相对路径按 output/latent 解析，可省略扩展名。"
                }),
            },
        }

    RETURN_TYPES = ("LATENT",)
    RETURN_NAMES = ("latent",)
    FUNCTION = "restore"
    CATEGORY = "H3 Upgrade Kit/采样"
    DESCRIPTION = ("恢复 H3Kit SelfLift K采保存的 latent。现在会完整恢复所有键、"
                   "原始 dtype 和 device，并保留 SEGMENT 等非张量数据的 Python 类型，"
                   "可直接接 K采 的 previous_latent，也可继续传给 H3Kit SelfLift 续接音画拼接。")

    def restore(self, file_path):
        return (load_latent_safetensors(file_path),)
